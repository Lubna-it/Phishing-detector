"""اختبارات وحدة (unit tests) للتأكد من صحة استخراج الخصائص من الروابط."""

import sys
import os
sys.path.append(os.path.join(os.path.dirname(__file__), "..", "src"))

from feature_extractor import extract_features  # noqa: E402


def test_https_detection():
    f = extract_features("https://example.com")
    assert f["has_https"] == 1

    f2 = extract_features("http://example.com")
    assert f2["has_https"] == 0


def test_ip_address_detection():
    f = extract_features("http://192.168.1.1/login")
    assert f["has_ip_address"] == 1


def test_suspicious_word_detection():
    f = extract_features("http://secure-verify-login.com")
    assert f["has_suspicious_word"] == 1


def test_shortener_detection():
    f = extract_features("http://bit.ly/abc123")
    assert f["is_shortened"] == 1


def test_normal_legit_url():
    f = extract_features("https://www.wikipedia.org/wiki/Security")
    assert f["has_ip_address"] == 0
    assert f["is_shortened"] == 0


if __name__ == "__main__":
    test_https_detection()
    test_ip_address_detection()
    test_suspicious_word_detection()
    test_shortener_detection()
    test_normal_legit_url()
    print("✅ جميع الاختبارات نجحت")
