"""
app.py
------
تطبيق ويب بسيط (Flask) يتيح للمستخدم إدخال رابط والحصول فورًا على
تصنيف: آمن ✅ أو مشبوه/تصيّد ⚠️ مع نسبة الثقة وأهم الأسباب.

للتشغيل:
    python app.py
ثم افتح المتصفح على: http://127.0.0.1:5000
"""

import os
import sys
import joblib

sys.path.append(os.path.join(os.path.dirname(__file__), "src"))
from feature_extractor import extract_features, FEATURE_NAMES  # noqa: E402

from flask import Flask, render_template, request, jsonify

app = Flask(__name__)

MODEL_PATH = "models/phishing_model.pkl"
model = None
if os.path.exists(MODEL_PATH):
    model = joblib.load(MODEL_PATH)


def explain_reasons(feats: dict) -> list:
    """يبني تفسيرًا مبسطًا مقروءًا للمستخدم بناءً على الخصائص المستخرجة."""
    reasons = []
    if feats["has_ip_address"]:
        reasons.append("الرابط يستخدم عنوان IP بدل اسم نطاق حقيقي")
    if not feats["has_https"]:
        reasons.append("الرابط لا يستخدم بروتوكول HTTPS الآمن")
    if feats["has_suspicious_word"]:
        reasons.append("يحتوي على كلمات مشبوهة مثل verify/secure/login")
    if feats["is_shortened"]:
        reasons.append("رابط مختصر (URL shortener) يُخفي الوجهة الحقيقية")
    if feats["num_subdomains"] >= 2:
        reasons.append("عدد نطاقات فرعية غير معتاد")
    if feats["domain_entropy"] > 3.8:
        reasons.append("اسم النطاق يبدو عشوائيًا (entropy مرتفع)")
    if feats["url_length"] > 75:
        reasons.append("طول الرابط أكبر من المعتاد")
    return reasons or ["لا توجد مؤشرات خطر واضحة في بنية الرابط"]


@app.route("/")
def index():
    return render_template("index.html")


@app.route("/api/check", methods=["POST"])
def check_url():
    if model is None:
        return jsonify({"error": "النموذج غير مدرَّب بعد. شغّل train_model.py أولًا."}), 400

    url = request.json.get("url", "").strip()
    if not url:
        return jsonify({"error": "الرجاء إدخال رابط"}), 400

    feats = extract_features(url)
    vector = [[feats[name] for name in FEATURE_NAMES]]

    prediction = model.predict(vector)[0]
    proba = model.predict_proba(vector)[0]
    confidence = round(max(proba) * 100, 2)

    return jsonify({
        "url": url,
        "label": "phishing" if prediction == 1 else "legitimate",
        "label_ar": "⚠️ رابط تصيّد محتمل" if prediction == 1 else "✅ رابط يبدو آمنًا",
        "confidence": confidence,
        "reasons": explain_reasons(feats),
        "features": feats,
    })


if __name__ == "__main__":
    app.run(debug=True)
