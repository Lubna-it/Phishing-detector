"""
generate_dataset.py
--------------------
يولّد مجموعة بيانات (dataset) تجريبية من روابط شرعية وروابط تصيّد
لتدريب النموذج. هذه بيانات اصطناعية (synthetic) للتجربة والتعلّم فقط.

⚠️ للاستخدام الحقيقي/الأكاديمي: استبدل هذا بمجموعة بيانات حقيقية مثل:
   - PhishTank (https://phishtank.org)
   - UCI Phishing Websites Dataset
   - Kaggle: "Phishing Site URLs"
"""

import csv
import random
import string
import os

LEGIT_DOMAINS = [
    "google.com", "wikipedia.org", "github.com", "microsoft.com",
    "amazon.com", "apple.com", "linkedin.com", "twitter.com",
    "stackoverflow.com", "mit.edu", "un.org", "who.int",
    "misk.org.sa", "sa.gov.sa", "moe.gov.sa", "kau.edu.sa"
]

LEGIT_PATHS = ["", "/about", "/products", "/en/help", "/news/2024",
               "/docs/api", "/careers", "/contact-us", "/blog/post-1"]

PHISH_KEYWORDS = ["secure", "verify", "account", "update", "confirm",
                   "signin", "login", "bank-alert", "billing-support"]

PHISH_TLDS = [".xyz", ".top", ".click", ".info", ".online", ".site"]


def random_string(n):
    return "".join(random.choices(string.ascii_lowercase + string.digits, k=n))


def make_legit_url():
    domain = random.choice(LEGIT_DOMAINS)
    path = random.choice(LEGIT_PATHS)
    scheme = "https"
    return f"{scheme}://www.{domain}{path}"


def make_phishing_url():
    style = random.choice(["fake_subdomain", "ip_based", "typo_domain", "long_random"])
    keyword = random.choice(PHISH_KEYWORDS)

    if style == "fake_subdomain":
        base = random.choice(LEGIT_DOMAINS).split(".")[0]
        return f"http://{keyword}-{base}.{random_string(6)}{random.choice(PHISH_TLDS)}/{keyword}"

    if style == "ip_based":
        ip = ".".join(str(random.randint(1, 255)) for _ in range(4))
        return f"http://{ip}/{keyword}/login.php"

    if style == "typo_domain":
        base = random.choice(LEGIT_DOMAINS)
        typo = base.replace("o", "0", 1).replace(".", f"-{keyword}.", 1)
        return f"http://{typo}/account/{random_string(5)}"

    # long_random
    return f"http://{random_string(10)}.{random_string(4)}{random.choice(PHISH_TLDS)}/{keyword}/{random_string(8)}"


def generate(n_per_class=500, out_path="data/urls_dataset.csv"):
    os.makedirs(os.path.dirname(out_path), exist_ok=True)
    rows = []
    for _ in range(n_per_class):
        rows.append((make_legit_url(), 0))       # 0 = legitimate
        rows.append((make_phishing_url(), 1))    # 1 = phishing

    random.shuffle(rows)
    with open(out_path, "w", newline="", encoding="utf-8") as f:
        writer = csv.writer(f)
        writer.writerow(["url", "label"])
        writer.writerows(rows)

    print(f"✅ تم إنشاء {len(rows)} رابط في: {out_path}")


if __name__ == "__main__":
    generate()
