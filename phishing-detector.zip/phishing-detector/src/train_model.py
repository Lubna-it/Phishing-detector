"""
train_model.py
---------------
يدرّب نموذج Random Forest للتمييز بين الروابط الشرعية وروابط التصيّد،
ثم يحفظ النموذج المدرّب في models/phishing_model.pkl
"""

import csv
import joblib
import os
from sklearn.ensemble import RandomForestClassifier
from sklearn.model_selection import train_test_split
from sklearn.metrics import (
    accuracy_score, precision_score, recall_score, f1_score,
    confusion_matrix, classification_report
)

from feature_extractor import extract_features, FEATURE_NAMES


def load_dataset(path=None):
    if path is None:
        base = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
        path = os.path.join(base, "data", "urls_dataset.csv")
    X, y = [], []
    with open(path, encoding="utf-8") as f:
        reader = csv.DictReader(f)
        for row in reader:
            feats = extract_features(row["url"])
            X.append([feats[name] for name in FEATURE_NAMES])
            y.append(int(row["label"]))
    return X, y


def main():
    print("📥 تحميل البيانات واستخراج الخصائص...")
    X, y = load_dataset()
    X_train, X_test, y_train, y_test = train_test_split(
        X, y, test_size=0.2, random_state=42, stratify=y
    )

    print("🧠 تدريب نموذج Random Forest...")
    model = RandomForestClassifier(
        n_estimators=200, max_depth=12, random_state=42, n_jobs=-1
    )
    model.fit(X_train, y_train)

    y_pred = model.predict(X_test)

    print("\n📊 نتائج التقييم:")
    print(f"Accuracy : {accuracy_score(y_test, y_pred):.4f}")
    print(f"Precision: {precision_score(y_test, y_pred):.4f}")
    print(f"Recall   : {recall_score(y_test, y_pred):.4f}")
    print(f"F1-score : {f1_score(y_test, y_pred):.4f}")
    print("\nConfusion Matrix:")
    print(confusion_matrix(y_test, y_pred))
    print("\nClassification Report:")
    print(classification_report(y_test, y_pred, target_names=["Legitimate", "Phishing"]))

    print("\n🔎 أهم 5 خصائص أثرت على القرار:")
    importances = sorted(
        zip(FEATURE_NAMES, model.feature_importances_),
        key=lambda x: x[1], reverse=True
    )
    for name, score in importances[:5]:
        print(f"  - {name}: {score:.3f}")

    base = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
    models_dir = os.path.join(base, "models")
    os.makedirs(models_dir, exist_ok=True)
    joblib.dump(model, os.path.join(models_dir, "phishing_model.pkl"))
    print(f"\n💾 تم حفظ النموذج في {os.path.join(models_dir, 'phishing_model.pkl')}")


if __name__ == "__main__":
    main()
