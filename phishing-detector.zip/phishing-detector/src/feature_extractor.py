"""
feature_extractor.py
---------------------
يستخرج خصائص (features) رقمية من رابط (URL) لاستخدامها في نموذج تعلم الآلة
للتمييز بين الروابط الشرعية (legitimate) وروابط التصيّد الاحتيالي (phishing).

كل دالة تمثل "مؤشر أمني" (security indicator) معروف في أبحاث كشف التصيّد.
"""

import re
import math
from urllib.parse import urlparse

SUSPICIOUS_WORDS = [
    "secure", "account", "update", "verify", "login", "signin", "bank",
    "confirm", "password", "banking", "billing", "webscr", "ebayisapi"
]

SHORTENING_SERVICES = [
    "bit.ly", "tinyurl.com", "goo.gl", "t.co", "ow.ly", "is.gd", "buff.ly"
]


def shannon_entropy(s: str) -> float:
    """يحسب عشوائية النص - الروابط المُولّدة آليًا غالبًا أعلى عشوائية."""
    if not s:
        return 0.0
    prob = [s.count(c) / len(s) for c in set(s)]
    return -sum(p * math.log2(p) for p in prob)


def extract_features(url: str) -> dict:
    """يستخرج 17 خاصية رقمية من الرابط المُعطى."""
    parsed = urlparse(url if "://" in url else "http://" + url)
    domain = parsed.netloc.lower()
    path = parsed.path or ""
    full = url.lower()

    features = {
        "url_length": len(url),
        "domain_length": len(domain),
        "path_length": len(path),
        "num_dots": url.count("."),
        "num_hyphens": url.count("-"),
        "num_underscores": url.count("_"),
        "num_slashes": url.count("/"),
        "num_at_symbols": url.count("@"),
        "num_digits": sum(c.isdigit() for c in url),
        "has_ip_address": 1 if re.match(
            r"^(\d{1,3}\.){3}\d{1,3}$", domain.split(":")[0]) else 0,
        "has_https": 1 if parsed.scheme == "https" else 0,
        "has_suspicious_word": 1 if any(w in full for w in SUSPICIOUS_WORDS) else 0,
        "is_shortened": 1 if any(s in domain for s in SHORTENING_SERVICES) else 0,
        "num_subdomains": max(domain.count(".") - 1, 0),
        "domain_entropy": round(shannon_entropy(domain), 3),
        "has_double_slash_redirect": 1 if "//" in path else 0,
        "abnormal_port": 1 if (":" in domain and domain.split(":")[-1] not in ("80", "443")) else 0,
    }
    return features


FEATURE_NAMES = list(extract_features("http://example.com").keys())
